import { Button, Typography } from '@mui/material'
import React, { useEffect, useState } from 'react'

const UseE = () => {
    var [name, setName] = useState()
    const changeHname = () =>{
        setName("Home")
    }
    const changeCname = () =>{
        setName("Contact")
    }
    const changeGname = () =>{
        setName("Gallery")
    } 
    useEffect (()=>{
        changeHname()
    },[])
  return (
    <div>
        <Typography>Welcome To {name} </Typography>&nbsp; &nbsp; 
        <Button onClick={changeHname} variant='contained'>Home</Button>&nbsp; &nbsp; 
        <Button onClick={changeCname} variant='contained'>Contact</Button>&nbsp; &nbsp; 
        <Button onClick={changeGname} variant='contained'>Gallery</Button>
    </div>
  )
}

export default UseE