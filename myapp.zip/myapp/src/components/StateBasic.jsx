import { Button, TextField, Typography } from '@mui/material'
import React, { useState } from 'react'

const StateBasic = () => {
    // var name="Archana"
    var [fname,setFname]=useState("Joy")
    var [va1,setval]=useState();

    const changeName = ()=>{
    console.log("clicked")
    setFname(va1)
    setval("")
   }

   const inputHandler =(e)=>{
    console.log(e.target.value)
    // to store value
    setval(e.target.value)
   }

  return (
    <div>
        <Typography>My name is {fname}</Typography><br/>
        <TextField variant='outlined' label="Enter name" onChange={inputHandler} value={va1}/><br/><br/>
        <Button variant='contained' onClick={changeName}>Change</Button>
    </div>
  )
}

export default StateBasic